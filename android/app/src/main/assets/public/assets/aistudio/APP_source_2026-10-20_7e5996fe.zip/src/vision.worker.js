import {FilesetResolver,PoseLandmarker,HandLandmarker} from '@mediapipe/tasks-vision';
import {HandBackend} from './inference-backend.js';
let model=null,kind=null,backend=null;
self.onmessage=async({data})=>{
  try{
    if(data.type==='load'){
      kind=data.key==='hands'?'hands':'pose';
      self.postMessage({type:'status',message:'Загрузка модели · файл'});
      const response=await fetch(data.url,{credentials:'same-origin'});
      if(!response.ok)throw new Error(`Файл модели недоступен (HTTP ${response.status})`);
      const buffer=new Uint8Array(await response.arrayBuffer());
      if(buffer.byteLength<100000)throw new Error('Получен неверный файл модели. Откройте прямую ссылку сайта и войдите в аккаунт.');
      self.postMessage({type:'status',message:'Загрузка модели · запуск WASM'});
      const fileset=await FilesetResolver.forVisionTasks(data.wasm);
      const options={baseOptions:{modelAssetBuffer:buffer,delegate:'CPU'},runningMode:'VIDEO'};
      if(kind==='pose'){
        model=await PoseLandmarker.createFromOptions(fileset,{...options,numPoses:1,minTrackingConfidence:0.6,minPoseDetectionConfidence:0.6,minPosePresenceConfidence:0.6,outputSegmentationMasks:false});
      }else{
        backend=new HandBackend({
          onInfo:info=>self.postMessage({type:'backend',...info}),
          create:async delegate=>{
            let canvas;
            if(delegate==='GPU'){
              if(typeof OffscreenCanvas==='undefined')throw new Error('OffscreenCanvas не поддерживается');
              canvas=new OffscreenCanvas(1,1);
              if(!canvas.getContext('webgl2'))throw new Error('WebGL2 недоступен в Worker');
            }
            return HandLandmarker.createFromOptions(fileset,{
              ...options,baseOptions:{modelAssetBuffer:buffer,delegate},...(canvas?{canvas}:{}),
              numHands:2,minTrackingConfidence:0.5,minHandDetectionConfidence:0.5,minHandPresenceConfidence:0.5,
            });
          },
        });
        await backend.load();
      }
      self.postMessage({type:'ready',...(backend?backend.info():{delegate:'CPU',backendStatus:'Выбран'})});
    }
    if(data.type==='frame'&&(model||backend)){
      const started=performance.now(),inputWidth=data.bitmap.width,inputHeight=data.bitmap.height,benchmarking=!!backend?.benchmarking;let result;
      try{result=backend?await backend.detect(data.bitmap,data.timestamp):model.detectForVideo(data.bitmap,data.timestamp);}finally{data.bitmap.close();}
      self.postMessage({type:'result',epoch:data.epoch,timestamp:data.timestamp,ms:performance.now()-started,inputWidth,inputHeight,benchmarking,
        ...(backend?backend.info():{delegate:'CPU',backendStatus:'Выбран',backendBenchmark:null,fallbackReason:null}),
        landmarks:result.landmarks||[],scores:result.handedness?.map(h=>h[0]?.score??0)||[]});
    }
  }catch(e){self.postMessage({type:'error',message:e?.message||String(e)});}
};
